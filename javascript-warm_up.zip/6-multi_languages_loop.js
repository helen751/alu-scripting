#!/usr/bin/node
const langs = ['C is fun', 'Python is cool', 'JavaScript is amazing'];
for (const line of langs) {
  console.log(line);
}
