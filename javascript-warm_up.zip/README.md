# JavaScript Warm Up

This directory contains simple JavaScript scripts for the ALU higher level programming project.
Each script demonstrates basic syntax, argument handling, loops, and functions.

Run with:
```bash
./<scriptname>.js
```
